Installing Lean on Ubuntu 16.04
-------------------------------

### Basic packages

    sudo apt-get install git libgmp-dev cmake

### Optional Packages: ninja

    sudo apt-get install ninja
