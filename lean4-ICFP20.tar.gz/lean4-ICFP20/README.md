We are currently developing Lean 4. [Lean 3](https://github.com/leanprover/lean) is still the latest official release.
This repository contains work in progress.

**Important**. Unless you are one of our collaborators
- We strongly suggest you use Lean 3.
- Pull requests are not welcome.
- New issues are not welcome, and will be closed without any feedback.
