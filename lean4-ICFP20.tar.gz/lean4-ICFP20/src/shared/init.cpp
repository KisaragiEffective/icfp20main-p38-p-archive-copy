/*
Copyright (c) 2015 Microsoft Corporation. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.

Author: Leonardo de Moura
*/
#include "initialize/init.h"
namespace lean {
// automatic initialization for the shared library
initializer g_init;
}
